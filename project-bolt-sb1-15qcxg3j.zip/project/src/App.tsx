import React from 'react';
import { BookOpen, GraduationCap, Users, BookMarked, BrainCircuit, Rocket, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-700">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="text-white text-2xl font-bold">Lazy Science</div>
            <div className="hidden md:flex space-x-8">
              <a href="#" className="text-white hover:text-blue-200">Home</a>
              <a href="#" className="text-white hover:text-blue-200">Courses</a>
              <a href="#" className="text-white hover:text-blue-200">Resources</a>
              <a href="#" className="text-white hover:text-blue-200">About</a>
            </div>
            <button className="bg-white text-blue-600 px-6 py-2 rounded-full font-semibold hover:bg-blue-50">
              Get Started
            </button>
          </div>
        </nav>
        
        <div className="container mx-auto px-6 py-20">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2">
              <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                Lazy Tech Wave: The future of learning, simplified effortlessly.
              </h1>
              <p className="mt-4 text-xl text-blue-100">
                Access premium study materials, future-ready notes, and interactive resources
              </p>
              <button className="mt-8 bg-white text-blue-600 px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-50 flex items-center">
                Explore Resources <ChevronRight className="ml-2" />
              </button>
            </div>
            <div className="md:w-1/2 mt-10 md:mt-0">
              <img 
                src="https://lh3.googleusercontent.com/a/ACg8ocLtsCNyVjvldN5tYlXVCns8dJngcgbUShSlYvvKYd1fK1wgszdE=s360-c-no"
                alt="Students studying"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-16">Why Choose Lazy Science?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <FeatureCard 
              icon={<BookOpen className="w-10 h-10 text-blue-600" />}
              title="Comprehensive Notes"
              description="Access detailed, well-structured notes covering all major topics"
            />
            <FeatureCard 
              icon={<BrainCircuit className="w-10 h-10 text-blue-600" />}
              title="Future Technology"
              description="Stay ahead with notes on emerging technologies and future trends"
            />
            <FeatureCard 
              icon={<Users className="w-10 h-10 text-blue-600" />}
              title="Collaborative Learning"
              description="Join a community of learners and share resources"
            />
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-16">Popular Subjects</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <SubjectCard 
              icon={<Rocket className="w-8 h-8" />}
              title="Computer Science"
              count="24+ Resources"
            />
            <SubjectCard 
              icon={<BookMarked className="w-8 h-8" />}
              title="Mathematics"
              count="18+ Resources"
            />
            <SubjectCard 
              icon={<GraduationCap className="w-8 h-8" />}
              title="Physics"
              count="15+ Resources"
            />
            <SubjectCard 
              icon={<BrainCircuit className="w-8 h-8" />}
              title="AI & ML"
              count="12+ Resources"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">LAZY TECH WAVE</h3>
              <p className="text-gray-400">Empowering education through technology and innovation.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Home</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Courses</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Resources</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Study Materials</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Notes</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Videos</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
              <p className="text-gray-400">Email: info@lazytechwave.com</p>
              <p className="text-gray-400">Phone: +1 234 567 890</p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 LAZY TECH WAVE. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 text-center mb-4">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </div>
  );
}

function SubjectCard({ icon, title, count }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition-shadow border border-gray-100 cursor-pointer group">
      <div className="flex items-center space-x-4">
        <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
          <p className="text-gray-500 text-sm">{count}</p>
        </div>
      </div>
    </div>
  );
}

export default App;